# Formulario-de-cadastro-responsivo-com-html-e-css
Neste repositório eu fiz um formulário de cadastro responsivo e bonito usando html e css.

Olá Amigos, neste vídeo você vai aprender a como criar um formulário de cadastro responsivo usando html e css será uma página de cadastro responsiva com html e css muito simples com objectivo de melhorar os seu conhecimentos no desenvolvimento web front-end!. Bora aprender como criar esta tela de cadastro/pagina de cadastro com html5 e css3.

Para aprender a montar a um formulário de cadastro responsivo que é muito fundamental para um desenvolvedor front-end ou também back-end nós vamos utilizar muitas tag principalmente as tags usadas para criar formulários, tela de login ou qualquer outros tipos de formulario, nós vamos usar muito flexbox tanto para o design e também para a responsividade.

## [🛠Assistir](https://youtu.be/Y6jNn0K-4c8)
## [⚠Me Ajude](https://www.youtube.com/channel/UCxKIsX5OXyyNWVmomuDc-LA?sub_confirmation=1)
# Preview
![[PASSO-A-PASSO]Criando-Um-Formulário-De-Cadastro-RESPONSIVO-HTML-E-CSS](/[PASSO-A-PASSO]Criando-Um-Formulário-De-Cadastro-RESPONSIVO-HTML-E-CSS.png)
